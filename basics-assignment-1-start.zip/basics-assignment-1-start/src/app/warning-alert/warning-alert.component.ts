import { Component } from '@angular/core';

@Component({
  selector: 'app-warning-alert',
  // templateUrl: './warning-alert.component.html',
  template: '<h4>WARNING: </h4><p>Here is the notification from warning component!</p>',
  // styleUrl: './warning-alert.component.css'
  styles: ['h4 { color: red; }']
})
export class WarningAlertComponent {

}
