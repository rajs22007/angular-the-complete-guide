import { Component } from '@angular/core';

@Component({
  // selector: '.app-success-alert',
  selector: 'app-success-alert',
  // templateUrl: './success-alert.component.html',
  template: '<h4>SUCCESS: </h4><p>Notification from success alert component!</p>',
  // styleUrl: './success-alert.component.css'
  styles: ['h4 { color: green; }']
})
export class SuccessAlertComponent {

}
